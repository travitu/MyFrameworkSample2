﻿nendSDK for iOS

nendをiOSで利用するためのSDKです。

・ドキュメント
https://github.com/fan-ADN/nendSDK-iOS/wiki

・サンプル
https://github.com/fan-ADN/nendSDK-iOS

-----------------------------------------------------------
nend / http://nend.net 
 (c) F@N Communications, Inc.
-----------------------------------------------------------
